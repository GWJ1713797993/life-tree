import storage from '@/libs/Storage'

export default storage.getInstance()
