export default [
  {
    path: '/happen',
    name: 'Happen',
    component: () => import('@/views/happen')
  }
]
