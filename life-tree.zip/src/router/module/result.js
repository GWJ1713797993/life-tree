export default [
  {
    path: '/result',
    name: 'Result',
    component: () => import('@/views/result')
  }
]
