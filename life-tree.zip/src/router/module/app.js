export default [
  {
    path: '*',
    redirect: '/404'
  }
]
