export default [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/home')
  }
]
