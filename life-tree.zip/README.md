# template-h5

## Project setup
```
yarn install
```

### Compiles and hot-reloads for development
```
yarn dev / npm run dev
```

### Compiles and minifies for production
```
yarn build
```

### Run your tests
```
yarn run test
```

### Lints and fixes files
```
yarn run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
